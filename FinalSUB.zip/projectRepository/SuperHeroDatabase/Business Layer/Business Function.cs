﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperHeroDatabase.Data_Layer;

namespace SuperHeroDatabase.Business_Layer
{
    internal class Business_Function
    {
        private readonly DataHandler _dataHandler;

        public Business_Function()
        {
            _dataHandler = new DataHandler();
        }

        public List<Superhero> GetAllHeroes()
        {
            return _dataHandler.LoadAll();
        }

        public bool AddHero(Superhero hero, out string error)
        {
            error = null;
            if (hero == null)
            {
                error = "Hero is null.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(hero.HeroID))
            {
                error = "Hero ID is required.";
                return false;
            }

            // Prevent duplicate HeroID
            var existing = GetAllHeroes().FirstOrDefault(h => string.Equals(h.HeroID, hero.HeroID, StringComparison.OrdinalIgnoreCase));
            if (existing != null)
            {
                error = "Hero with this ID already exists.";
                return false;
            }

            // Derive fields
            hero.Rank = Logic.DetermineRank(hero.ExamScore);
            hero.ThreatLevel = Logic.DetermineThreat(hero.Rank);

            return _dataHandler.Add(hero, out error);
        }

        public bool UpdateHero(Superhero hero, out string error)
        {
            error = null;
            if (hero == null)
            {
                error = "Hero is null.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(hero.HeroID))
            {
                error = "Hero ID is required.";
                return false;
            }

            hero.Rank = Logic.DetermineRank(hero.ExamScore);
            hero.ThreatLevel = Logic.DetermineThreat(hero.Rank);

            return _dataHandler.Update(hero, out error);
        }

        public bool DeleteHero(string heroId, out string error)
        {
            error = null;
            if (string.IsNullOrWhiteSpace(heroId))
            {
                error = "Hero ID is required for deletion.";
                return false;
            }
            return _dataHandler.Delete(heroId.Trim(), out error);
        }

        public bool GenerateSummary(out string summaryText, out string error)
        {
            summaryText = string.Empty;
            error = null;
            try
            {
                var list = GetAllHeroes();
                if (list == null || list.Count == 0)
                {
                    summaryText = "No superheroes found.";
                }
                else
                {
                    int total = list.Count;
                    double avgAge = list.Average(h => (double)h.Age);
                    double avgScore = list.Average(h => (double)h.ExamScore);
                    int s = list.Count(h => string.Equals(h.Rank, "S-Rank", StringComparison.OrdinalIgnoreCase));
                    int a = list.Count(h => string.Equals(h.Rank, "A-Rank", StringComparison.OrdinalIgnoreCase));
                    int b = list.Count(h => string.Equals(h.Rank, "B-Rank", StringComparison.OrdinalIgnoreCase));
                    int c = list.Count(h => string.Equals(h.Rank, "C-Rank", StringComparison.OrdinalIgnoreCase));

                    var sb = new StringBuilder();
                    sb.AppendLine("One Kick Heroes Academy - Summary Report");
                    sb.AppendLine("Total Superheroes: " + total);
                    sb.AppendLine("Average Age: " + avgAge.ToString("F2"));
                    sb.AppendLine("Average Exam Score: " + avgScore.ToString("F2"));
                    sb.AppendLine("S-Rank: " + s);
                    sb.AppendLine("A-Rank: " + a);
                    sb.AppendLine("B-Rank: " + b);
                    sb.AppendLine("C-Rank: " + c);

                    summaryText = sb.ToString();
                }

                // Persist
                if (!_dataHandler.SaveSummary(summaryText, out error))
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }
    }
}

   
