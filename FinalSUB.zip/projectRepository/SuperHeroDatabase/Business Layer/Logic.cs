﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace SuperHeroDatabase.Business_Layer
{
    internal class Logic
    {
        public static string DetermineRank(int score)
        {
            if (score >= 81 && score <= 100) return "S-Rank";
            if (score >= 61 && score <= 80) return "A-Rank";
            if (score >= 41 && score <= 60) return "B-Rank";
            if (score >= 0 && score <= 40) return "C-Rank";
            return "Unknown";
        }

        public static string DetermineThreat(string rank)
        {
            switch (rank)
            {
                case "S-Rank":
                    return "Finals Week (threat to the entire academy)";
                case "A-Rank":
                    return "Midterm Madness (threat to a department)";
                case "B-Rank":
                    return "Group Project Gone Wrong (threat to a study group)";
                case "C-Rank":
                    return "Pop Quiz (potential threat to an individual student)";
                default:
                    return "Unknown";
            }
        }
    }
}
