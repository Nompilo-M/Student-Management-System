﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using SuperHeroDatabase.Data_Layer;

namespace SuperHeroDatabase.Presentation_Layer
{
    internal class UserInput
    {
        public static bool TryParseHeroInputs(string id, string name, string ageText, string superpower, string scoreText, out Superhero hero, out string error)
        {
            hero = null;
            error = null;

            if (string.IsNullOrWhiteSpace(id))
            {
                error = "Hero ID is required.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(name))
            {
                error = "Name is required.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(superpower))
            {
                error = "Superpower is required.";
                return false;
            }

            int age;
            if (!int.TryParse(ageText, out age) || age < 0)
            {
                error = "Age must be a non-negative integer.";
                return false;
            }

            int score;
            if (!int.TryParse(scoreText, out score) || score < 0 || score > 100)
            {
                error = "Exam score must be an integer between 0 and 100.";
                return false;
            }

            hero = new Superhero
            {
                HeroID = id.Trim(),
                Name = name.Trim(),
                Age = age,
                Superpower = superpower.Trim(),
                ExamScore = score
            };

            return true;
        }

        public static void ShowError(string message)
        {
            MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        /// <summary>
        /// Shows an informational success message.
        /// </summary>
        public static void ShowSuccess(string message)
        {
            MessageBox.Show(message, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Clears the provided TextBox controls (helper for clearing form inputs).
        /// Example: UserInput.ClearInputs(txtHeroID, txtName, txtAge, ...);
        /// </summary>
        public static void ClearInputs(params TextBox[] textBoxes)
        {
            if (textBoxes == null) return;
            foreach (var tb in textBoxes)
            {
                if (tb == null) continue;
                tb.Text = string.Empty;
            }
        }
    }
}
