﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperHeroDatabase
{
    public class Superhero
    {
        public string HeroID { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Superpower { get; set; }
        public int ExamScore { get; set; }
        public string Rank { get; set; }
        public string ThreatLevel { get; set; }

        public void CalculateRankAndThreat()
        {
            if (ExamScore >= 90)
            {
                Rank = "S";
                ThreatLevel = "High";
            }
            else if (ExamScore >= 75)
            {
                Rank = "A";
                ThreatLevel = "Medium";
            }
            else if (ExamScore >= 50)
            {
                Rank = "B";
                ThreatLevel = "Low";
            }
            else
            {
                Rank = "C";
                ThreatLevel = "Minimal";
            }
        }

        public override string ToString()
        {
            return $"{HeroID},{Name},{Age},{Superpower},{ExamScore},{Rank},{ThreatLevel}";
        }
    }

}
