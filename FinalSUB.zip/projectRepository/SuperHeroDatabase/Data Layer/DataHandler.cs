﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperHeroDatabase.Data_Layer
{
    internal class DataHandler
    {
        private readonly string _filePath;
        private readonly string _summaryPath;
        private const char Delim = '|';

        public DataHandler()
        {
            var folder = AppDomain.CurrentDomain.BaseDirectory;
            _filePath = Path.Combine(folder, "superheroes.txt");
            _summaryPath = Path.Combine(folder, "summary.txt");

            // Ensure file exists
            if (!File.Exists(_filePath))
            {
                File.WriteAllText(_filePath, string.Empty, Encoding.UTF8);
            }
        }

        public List<Superhero> LoadAll()
        {
            var list = new List<Superhero>();
            try
            {
                foreach (var line in File.ReadAllLines(_filePath))
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var parts = line.Split(Delim);
                    if (parts.Length < 7) continue;

                    int age = 0, score = 0;
                    int.TryParse(parts[2], out age);
                    int.TryParse(parts[4], out score);

                    list.Add(new Superhero
                    {
                        HeroID = parts[0],
                        Name = parts[1],
                        Age = age,
                        Superpower = parts[3],
                        ExamScore = score,
                        Rank = parts[5],
                        ThreatLevel = parts[6]
                    });
                }
            }
            catch (Exception)
            {
                // Return empty list on error
            }
            return list;
        }

        private string ToLine(Superhero s)
        {
            return string.Join(Delim.ToString(), new[]
            {
                s.HeroID ?? string.Empty,
                s.Name ?? string.Empty,
                s.Age.ToString(),
                s.Superpower ?? string.Empty,
                s.ExamScore.ToString(),
                s.Rank ?? string.Empty,
                s.ThreatLevel ?? string.Empty
            });
        }

        public bool SaveAll(List<Superhero> heroes, out string error)
        {
            error = null;
            try
            {
                var lines = heroes.Select(ToLine).ToArray();
                File.WriteAllLines(_filePath, lines, Encoding.UTF8);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        public bool Add(Superhero hero, out string error)
        {
            error = null;
            try
            {
                var line = ToLine(hero);
                File.AppendAllLines(_filePath, new[] { line }, Encoding.UTF8);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        public bool Update(Superhero updated, out string error)
        {
            error = null;
            try
            {
                var list = LoadAll();
                var idx = list.FindIndex(h => string.Equals(h.HeroID, updated.HeroID, StringComparison.OrdinalIgnoreCase));
                if (idx < 0)
                {
                    error = "Hero ID not found.";
                    return false;
                }
                list[idx] = updated;
                return SaveAll(list, out error);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        public bool Delete(string heroId, out string error)
        {
            error = null;
            try
            {
                var list = LoadAll();
                var newList = list.Where(h => !string.Equals(h.HeroID, heroId, StringComparison.OrdinalIgnoreCase)).ToList();
                if (newList.Count == list.Count)
                {
                    error = "Hero ID not found.";
                    return false;
                }
                return SaveAll(newList, out error);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        public bool SaveSummary(string summaryText, out string error)
        {
            error = null;
            try
            {
                File.WriteAllText(_summaryPath, summaryText, Encoding.UTF8);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }
    }
}

