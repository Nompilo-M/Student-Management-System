﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperHeroDatabase.Business_Layer;
using SuperHeroDatabase.Data_Layer;
using SuperHeroDatabase.Presentation_Layer;

namespace SuperHeroDatabase
{
    public partial class Form1 : Form
    {
        private readonly Business_Function _bf = new Business_Function();
        private BindingList<Superhero> _bindingList;
        public Form1()
        {
            InitializeComponent();
        }

        //add button 
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Superhero hero = new Superhero
            {
                HeroID = txtHeroID.Text,
                Name = txtName.Text,
                Age = int.Parse(txtAge.Text),
                Superpower = txtPower.Text,  
                ExamScore = int.Parse(txtScore.Text)  
            };

            hero.CalculateRankAndThreat();

            // Append hero details to superheroes.txt
            using (StreamWriter sw = new StreamWriter("superheroes.txt", true))
            {
                sw.WriteLine(hero.ToString());
            }

            MessageBox.Show("Hero added successfully!");
            ClearInputFields();
        }
        private void ClearInputFields()
        {
            txtHeroID.Clear();
            txtName.Clear();
            txtAge.Clear();
            txtPower.Clear(); 
            txtScore.Clear();  
        }

        //View all heros buttpn
        private void btnView_Click(object sender, EventArgs e)
        {
            List<Superhero> heroes = new List<Superhero>();
            if (File.Exists("superheroes.txt"))
            {
                var lines = File.ReadAllLines("superheroes.txt");
                foreach (var line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 7)
                    {
                        heroes.Add(new Superhero
                        {
                            HeroID = parts[0],
                            Name = parts[1],
                            Age = int.Parse(parts[2]),
                            Superpower = parts[3],
                            ExamScore = int.Parse(parts[4]),
                            Rank = parts[5],
                            ThreatLevel = parts[6]
                        });
                    }
                }
            }
            dataGridView1.DataSource = heroes;  
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Validate required fields
            var heroId = txtHeroID.Text?.Trim();
            var name = txtName.Text?.Trim();
            var superpower = txtPower.Text?.Trim();

            if (string.IsNullOrEmpty(heroId))
            {
                MessageBox.Show("No Hero selected. Select a row or enter a HeroID to update.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Name is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(superpower))
            {
                MessageBox.Show("Superpower is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtAge.Text?.Trim(), out var age))
            {
                MessageBox.Show("Age must be a valid integer.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtScore.Text?.Trim(), out var examScore))
            {
                MessageBox.Show("Exam Score must be a valid integer.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Build updated object
            var updatedHero = new Superhero
            {
                HeroID = heroId,
                Name = name,
                Age = age,
                Superpower = superpower,
                ExamScore = examScore
                // Rank and ThreatLevel are computed by Business_Function if applicable
            };

            // Call business layer to update
            if (!_bf.UpdateHero(updatedHero, out var error))
            {
                MessageBox.Show($"Update failed: {error}", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Refresh UI
            LoadSuperheroes();
            dataGridView1.Refresh();
            dataGridView1.ClearSelection();
            txtHeroID.Enabled = true;

            MessageBox.Show("Hero updated successfully.", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Determine hero id to delete (prefer selected row but fallback to text box)
            string heroId = null;
            if (dataGridView1.SelectedRows != null && dataGridView1.SelectedRows.Count > 0)
            {
                var row = dataGridView1.SelectedRows[0].DataBoundItem as Superhero;
                if (row != null) heroId = row.HeroID;
            }

            if (string.IsNullOrEmpty(heroId))
            {
                heroId = txtHeroID.Text?.Trim();
            }

            if (string.IsNullOrEmpty(heroId))
            {
                MessageBox.Show("No Hero selected to delete. Select a row or enter a HeroID.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Confirm deletion
            var confirm = MessageBox.Show($"Are you sure you want to delete hero '{heroId}'? This action cannot be undone.", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes)
            {
                return;
            }

            // Call business layer to delete
            if (!_bf.DeleteHero(heroId, out var error))
            {
                MessageBox.Show($"Delete failed: {error}", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Refresh UI and clear inputs
            LoadSuperheroes();
            dataGridView1.Refresh();
            dataGridView1.ClearSelection();
            txtHeroID.Enabled = true;
            UserInput.ClearInputs(txtHeroID, txtName, txtAge, txtPower, txtScore);

            MessageBox.Show("Hero deleted successfully.", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        

        private void dgvHeroes(object sender, EventArgs e)
        {

        }

        private void txtPower_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadSuperheroes();
            dataGridView1.Refresh();
            UserInput.ShowSuccess("Data refreshed successfully!");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadSuperheroes();
        }
        private void LoadSuperheroes()
        {
            var list = _bf.GetAllHeroes() ?? new List<Superhero>();
            _bindingList = new BindingList<Superhero>(list);
            dataGridView1.DataSource = _bindingList;
            dataGridView1.Refresh();
        }
        // SELECTION CHANGED
        private void dataGridViewSuperheroes_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows == null || dataGridView1.SelectedRows.Count == 0)
            {
                return;
            }

            var row = dataGridView1.SelectedRows[0].DataBoundItem as Superhero;
            if (row == null) return;

            txtHeroID.Text = row.HeroID;
            txtName.Text = row.Name;
            txtAge.Text = row.Age.ToString();
            txtPower.Text = row.Superpower;
            txtScore.Text = row.ExamScore.ToString();

            // When a row is selected, disable editing of HeroID to avoid accidental ID changes
            txtHeroID.Enabled = false;
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            try
            {
                // Load superheroes from file
                string[] lines = File.ReadAllLines("superheroes.txt");

                var heroes = new List<Superhero>();
                

                // --- Calculations ---
                int totalHeroes = heroes.Count;
                double avgAge = heroes.Average(h => h.Age);
                double avgExam = heroes.Average(h => h.ExamScore);

                int rankS = heroes.Count(h => h.Rank == "S");
                int rankA = heroes.Count(h => h.Rank == "A");
                int rankB = heroes.Count(h => h.Rank == "B");
                int rankC = heroes.Count(h => h.Rank == "C");

                // --- Create summary text ---
                string summary =
                    "=== SUPERHERO SUMMARY REPORT ===\n" +
                    $"Date: {DateTime.Now}\n\n" +
                    $"Total Heroes: {totalHeroes}\n" +
                    $"Average Age: {avgAge:F1}\n" +
                    $"Average Exam Score: {avgExam:F1}\n\n" +
                    $"Rank Breakdown:\n" +
                    $"S Rank: {rankS}\n" +
                    $"A Rank: {rankA}\n" +
                    $"B Rank: {rankB}\n" +
                    $"C Rank: {rankC}\n";

                // Save the summary file
                File.WriteAllText("summary.txt", summary);

                // Notify the user
                MessageBox.Show("Summary report generated successfully!\n(summary.txt created)",
                                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error generating summary: {ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }

    }
}

