# Superhero Management System

## Overview
This application manages superhero data, allowing users to add, update, delete heroes, and generate summary reports.

## Features
- Add,View All, Update, Summary and Delete superheroes.
- Generates a summary report
- Save all data in `superheros.txt` and summary.txt.

## Version Control
Git is used for version tracking.
Each major feature is committed.
The repository is hosted on GitHub.

## Author
Regoratile Mokoene
Nompilo Mbense
Nasisipho Mbana
